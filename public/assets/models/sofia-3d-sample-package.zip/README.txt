Sofia Monteiro — 3D Asset Package
===================================
Models provided for real-time engines, game dev, and CGI.

License: Creative Commons Attribution 4.0 International (CC-BY 4.0)
You are free to:
- Share — copy and redistribute the material in any medium or format.
- Adapt — remix, transform, and build upon the material for any purpose, even commercially.

Official Sketchfab Profile:
https://sketchfab.com/sofias3dcontent/models

Included Formats:
- .blend (Blender 4.x scene with packed textures)
- .glb (glTF 2.0 binary with embedded PBR materials)
- .fbx (Autodesk FBX with UV maps & vertex normals)
- .obj (Wavefront OBJ + MTL)

Thank you for supporting independent 3D art!
